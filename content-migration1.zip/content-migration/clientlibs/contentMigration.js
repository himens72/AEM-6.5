(function(window, document, Granite, $) {
    "use strict";
    var importer_token = Math.floor(Math.random() * 0xffffff).toString(16),
        ticker,
        tickerFailCount,
        $summary,
        ui = $(window).adaptTo("foundation-ui");

    function doContentUpdate($wizard) {

        ticker = ui.waitTicker(Granite.I18n.get("Performing Content Migration ...."), "");
        var $formminmax = $($wizard).closest("form.foundation-form"),
		    field = $wizard.find("[data-granite-coral-multifield-name='./urlPath']"),
		    totalLinkCount = field.children('coral-multifield-item').length,
            folderPaths = "",
            reportPath = $wizard.find($("[name='reportPath']")[0]).val(),
            reportName = $wizard.find($("[name='reportName']")[0]).val(),
        	dryrun = $wizard.find($("[name='dryrun']")[0]).prop("checked"),
            rollback = $wizard.find($("[name='rollback']")[0]).prop("checked"),
            packageName = $wizard.find($("[name='packageName']")[0]).val(),
            fileName = $wizard.find($("[name='fileName']")[0]).val();


        for (var i = 0; i < totalLinkCount; i++) {
			folderPaths = folderPaths + field.find($("[name='./urlPath/item"+i+"/brandPath']")[0]).val() + ";";
        }

        var    formData = {
                folderPaths: folderPaths,
                reportPath: reportPath,
                reportName: reportName,
                dryrun: dryrun,
                file : fileName,
                packageName : packageName,
                rollback : rollback
        	};

        var $doneButton = $wizard.find(".all-done");
        updateResultsHeight($wizard);
        Granite.$.ajax({
            url: $wizard.prop("action"),
            data: JSON.stringify(formData),
            type: $wizard.prop("method"),
            contentType: "application/json",
            processData:false,
            success: function(data, textStatus, xhr) {
                ticker.clear();
                $doneButton.text(Granite.I18n.get("Done")).prop("disabled", false);
                if (_g.shared.HTTP.isOkStatus(xhr.status)) {
                    $wizard.find(".cq-commerce-content-migration-log").html(xhr.responseText);
                } else {
                    _onError(xhr.getResponseHeader("Message"));
                }
            },
            error: function(xhr, textStatus, errorThrown) {
                ticker.clear();
                $doneButton.text(Granite.I18n.get("Done")).prop("disabled", false);
                var response = _g.shared.HTTP.buildPostResponseFromHTML(xhr.responseText);
                _onError(response.headers["Message"]);
            }
        });

        //setTimeout(_updateTicker, TICKER_INTERVAL);
    }

    function _onError(message) {
        if (!message || typeof message !== "string") {
            message = Granite.I18n.get("content Migration File Generation failed.");
        }
        ui.alert(Granite.I18n.get("Error"), message, "error");
    }

    function updateResultsHeight($wizard) {
        var $results = $wizard.find(".cq-commerce-content-migration-logContainer"),
            $step = $results.closest("coral-panel"),
            height = $step.height() - 120;
        $results.height(height);
    }

     $(document).ready(function(e) {
        $(".hidden.import-provider-showhide-target.coral-Well").hide();
        var $wizard = $(".cq-commerce-content-migration", e.target).closest("form");
        if ($wizard.length) {
            $wizard.on("click", ".source-file-selected", function(e) {
                doContentUpdate($wizard);
            });
            $wizard.on("submit.cq-commerce-content-migration", function(e) {
                e.preventDefault();
                e.stopImmediatePropagation();
                var redirectTo = $wizard.find("[data-foundation-wizard-control-action=cancel]").attr("href");
                if (redirectTo) {
                    document.location.href = Granite.HTTP.externalize(redirectTo);
                }
            });

            $(window).on("resize", function () {
                updateResultsHeight($wizard);
            });
        }
    });


})(window, document, Granite, Granite.$);